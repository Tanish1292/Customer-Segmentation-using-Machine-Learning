"""Customer segmentation project package."""
